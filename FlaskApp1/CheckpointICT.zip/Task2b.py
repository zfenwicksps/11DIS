
isomorph1= []
isomorph2= []
word1 = "doko"
word2 = "book"
if len(word1) == len(word2):
	for indexa, chara in enumerate(word1):
		if word1.count(chara) > 1:
            for indexb, characterb in word1:
                if indexa < indexb:
				    if indexb == len(word1)-1 and chara == charb
					isomorph1.append('0')
				else:
					if chara == charb
						isomorph1.append(f"+{indexa-indexb}")
				else:
					isomorph1.append('0')
		else:
			isomorph1.append('0')

	If isomorph1 is the same as isomorph2:
		Tell user words are isomorphic pairs
	ELSE:
		Words are not isomorphic pairs
ELSE:
	Tell user words are different lengths
